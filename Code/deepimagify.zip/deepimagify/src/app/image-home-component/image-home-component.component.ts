import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-home-component',
  templateUrl: './image-home-component.component.html',
  styleUrls: ['./image-home-component.component.css']
})
export class ImageHomeComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
