import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-app-footer',
  templateUrl: './image-app-footer.component.html',
  styleUrls: ['./image-app-footer.component.css']
})
export class ImageAppFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
