import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-app-waves-effect',
  templateUrl: './image-app-waves-effect.component.html',
  styleUrls: ['./image-app-waves-effect.component.css']
})
export class ImageAppWavesEffectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
